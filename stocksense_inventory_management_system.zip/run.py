#!/usr/bin/env python3
"""
StockSense Inventory Management System - Server Launcher
Runs the Flask application on port 5001 (avoids macOS AirPlay Receiver port 5000 conflict)
and optionally opens the default browser.
"""
import os
import sys
import threading
import time
import webbrowser

from app import create_app
from models import db
from seed import seed_database

def open_browser(url, delay=1.0):
    time.sleep(delay)
    try:
        webbrowser.open(url)
    except Exception:
        pass

def main():
    app = create_app()
    
    # Ensure database is present; seed if not
    db_path = os.path.join(app.root_path, 'instance', 'stocksense.db')
    if not os.path.exists(db_path):
        print("🌱 Initializing and seeding database...")
        with app.app_context():
            seed_database()
            print("✅ Database seeded successfully.")

    port = int(os.environ.get('PORT', 5001))
    host = os.environ.get('HOST', '0.0.0.0')
    browse_url = f"http://localhost:{port}"

    print("=" * 60)
    print("  🚀 StockSense Enterprise Warehouse Terminal")
    print(f"  👉 Browse Link: {browse_url}")
    print(f"  👉 Local Network: http://127.0.0.1:{port}")
    print("  🔑 Demo Manager: manager@stocksense.demo / Manager@2026")
    print("  🔑 Demo Staff:   staff@stocksense.demo   / Staff@2026")
    print("=" * 60)

    # Launch browser in a background thread if not disabled
    if os.environ.get('NO_BROWSER') != '1':
        threading.Thread(target=open_browser, args=(browse_url,), daemon=True).start()

    app.run(host=host, port=port, debug=True)

if __name__ == '__main__':
    main()
