"""
StockSense Insights Engine.

Read-only analytics built on the SAME source of truth as the rest of the
application: the immutable StockMovement ledger (plus the operational
documents: receipts, deliveries, transfers, adjustments).

Nothing here stores or caches a second copy of inventory. Every figure is
recomputed from the ledger on request, so the warehouse map, analytics,
alerts, forecasting, audit trail and anomaly checks always agree with the
Products / Move History screens.
"""
import math
import statistics
from collections import defaultdict
from datetime import datetime, timedelta

from sqlalchemy import func

from models import (
    db, Product, Warehouse, Location, Receipt, ReceiptItem, Delivery, DeliveryItem,
    Transfer, TransferItem, Adjustment, AdjustmentItem, StockMovement, ActivityLog, User
)
from services.stock_engine import get_status

# ---------------------------------------------------------------------------
# Tunables (kept explicit so managers can reason about every number shown)
# ---------------------------------------------------------------------------
UTIL_WARNING_PCT = 80.0
UTIL_CRITICAL_PCT = 95.0

FORECAST_WINDOW_DAYS = 30        # look-back window for average daily usage
FORECAST_MIN_SPAN_DAYS = 14      # need at least this much history
FORECAST_MIN_EVENTS = 3          # and at least this many outbound events
FORECAST_COVER_DAYS = 14         # suggested reorder targets this many days of cover
FORECAST_ALERT_DAYS = 7          # alert when estimated depletion is within N days

ANOMALY_MIN_SAMPLES = 5          # need this many prior movements to judge "typical"
ANOMALY_REPEAT_ADJ_COUNT = 3     # adjustments on the same product ...
ANOMALY_REPEAT_ADJ_DAYS = 30     # ... within this many days
ANOMALY_SUDDEN_CHANGE_PCT = 25.0  # an adjustment moving a location balance by >= this %

OPENING_STOCK_LABEL = 'Opening Stock'

PENDING_RECEIPT_STATUSES = ('Draft', 'Waiting', 'Ready')
PENDING_DELIVERY_STATUSES = ('Draft', 'Waiting', 'Ready', 'Picked', 'Packed')
PENDING_TRANSFER_STATUSES = ('Draft', 'Waiting', 'Ready')


def _now():
    return datetime.utcnow()


def _is_opening(m):
    return m.operation == 'Adjustment' and (m.counterparty or '').strip().lower() == OPENING_STOCK_LABEL.lower()


# =========================================================================
# LEDGER BALANCES (bulk, single pass — equivalent to stock_engine.get_on_hand)
# =========================================================================

def location_balances():
    """{(product_id, location_id): on_hand} computed from the ledger in two grouped queries."""
    bal = defaultdict(float)
    inflow = db.session.query(
        StockMovement.product_id, StockMovement.to_location_id, func.sum(StockMovement.quantity)
    ).filter(StockMovement.to_location_id.isnot(None)).group_by(
        StockMovement.product_id, StockMovement.to_location_id).all()
    for pid, lid, qty in inflow:
        bal[(pid, lid)] += float(qty or 0)
    outflow = db.session.query(
        StockMovement.product_id, StockMovement.from_location_id, func.sum(StockMovement.quantity)
    ).filter(StockMovement.from_location_id.isnot(None)).group_by(
        StockMovement.product_id, StockMovement.from_location_id).all()
    for pid, lid, qty in outflow:
        bal[(pid, lid)] -= float(qty or 0)
    return bal


def company_totals(bal=None):
    """{product_id: total on hand across all locations}."""
    bal = bal if bal is not None else location_balances()
    totals = defaultdict(float)
    for (pid, _lid), qty in bal.items():
        totals[pid] += qty
    return totals


def capacity_status(used, capacity):
    """Returns dict(pct, available, status, level) for a capacity figure (None when not configured)."""
    if not capacity or capacity <= 0:
        return {'configured': False, 'pct': None, 'available': None,
                'status': 'Capacity not set', 'level': 'none'}
    pct = used / capacity * 100.0
    if pct > 100:
        status, level = 'Over capacity', 'critical'
    elif pct >= UTIL_CRITICAL_PCT:
        status, level = 'Critical', 'critical'
    elif pct >= UTIL_WARNING_PCT:
        status, level = 'High', 'warning'
    else:
        status, level = 'Normal', 'ok'
    return {'configured': True, 'pct': round(pct, 1), 'available': max(0.0, capacity - used),
            'status': status, 'level': level}


# =========================================================================
# WAREHOUSE MAP / FLOOR MAP
# =========================================================================

def _product_index():
    return {p.id: p for p in Product.query.all()}


def location_detail(loc, bal, products, totals):
    items = []
    for (pid, lid), qty in bal.items():
        if lid != loc.id or abs(qty) < 1e-9:
            continue
        p = products.get(pid)
        if not p:
            continue
        items.append({
            'product_id': p.id, 'name': p.name, 'sku': p.sku, 'uom': p.uom,
            'quantity': qty, 'reorder_level': p.reorder_level,
            'status': get_status(p, totals.get(p.id, 0.0)),
            'company_total': totals.get(p.id, 0.0),
        })
    items.sort(key=lambda x: -x['quantity'])
    used = sum(i['quantity'] for i in items)
    cap = capacity_status(used, loc.capacity)
    return {
        'id': loc.id, 'name': loc.name, 'code': loc.code, 'zone_type': loc.zone_type,
        'active': loc.active, 'capacity': loc.capacity, 'used': used,
        'products': items, 'product_count': len(items),
        'low_stock_count': sum(1 for i in items if i['status'] != 'In Stock'),
        'util': cap,
    }


def warehouse_overview(warehouse=None, bal=None):
    """Stats per active warehouse (or a single warehouse)."""
    bal = bal if bal is not None else location_balances()
    totals = company_totals(bal)
    products = _product_index()
    whs = [warehouse] if warehouse else Warehouse.query.filter_by(active=True).order_by(Warehouse.code).all()

    out = []
    for wh in whs:
        locs = [l for l in wh.locations]
        loc_ids = [l.id for l in locs]
        loc_details = [location_detail(l, bal, products, totals) for l in sorted(locs, key=lambda l: l.code)]
        stock = sum(d['used'] for d in loc_details)
        product_ids = {i['product_id'] for d in loc_details for i in d['products']}
        low_ids = {i['product_id'] for d in loc_details for i in d['products'] if i['status'] != 'In Stock'}

        pending_receipts = Receipt.query.filter(
            Receipt.status.in_(PENDING_RECEIPT_STATUSES),
            Receipt.destination_location_id.in_(loc_ids or [-1])).order_by(Receipt.scheduled_date).all()
        pending_deliveries = Delivery.query.filter(
            Delivery.status.in_(PENDING_DELIVERY_STATUSES),
            Delivery.source_location_id.in_(loc_ids or [-1])).order_by(Delivery.scheduled_date).all()
        pending_transfers = Transfer.query.filter(
            Transfer.status.in_(PENDING_TRANSFER_STATUSES),
            db.or_(Transfer.source_location_id.in_(loc_ids or [-1]),
                   Transfer.destination_location_id.in_(loc_ids or [-1]))).all()

        # Warehouse capacity: explicit value, else sum of configured location capacities
        cap_value = wh.capacity
        cap_source = 'warehouse'
        if not cap_value:
            loc_caps = [l.capacity for l in locs if l.capacity]
            if loc_caps and len(loc_caps) == len([l for l in locs if l.active]):
                cap_value = sum(loc_caps)
                cap_source = 'locations'
            else:
                cap_source = None

        out.append({
            'warehouse': wh,
            'id': wh.id, 'name': wh.name, 'code': wh.code, 'address': wh.address,
            'latitude': wh.latitude, 'longitude': wh.longitude,
            'locations': loc_details,
            'stock': stock,
            'product_count': len(product_ids),
            'low_stock_count': len(low_ids),
            'low_stock_products': sorted({products[i].name for i in low_ids}),
            'pending_receipts': pending_receipts,
            'pending_deliveries': pending_deliveries,
            'pending_transfers': pending_transfers,
            'capacity': cap_value, 'capacity_source': cap_source,
            'util': capacity_status(stock, cap_value),
        })
    return out


# =========================================================================
# ANALYTICS
# =========================================================================

def analytics(days=30):
    now = _now()
    start = now - timedelta(days=days)
    bal = location_balances()
    totals = company_totals(bal)
    products = {p.id: p for p in Product.query.filter_by(archived=False).all()}

    window = StockMovement.query.filter(StockMovement.at >= start).all()
    all_moves = StockMovement.query.order_by(StockMovement.at.asc()).all()

    received = defaultdict(float)
    delivered = defaultdict(float)
    transferred = defaultdict(float)
    transfer_count = defaultdict(int)
    adj_refs = defaultdict(set)
    for m in window:
        if m.operation == 'Receipt':
            received[m.product_id] += m.quantity
        elif m.operation == 'Delivery':
            delivered[m.product_id] += m.quantity
        elif m.operation == 'Internal Transfer':
            transferred[m.product_id] += m.quantity
            transfer_count[m.product_id] += 1
        elif m.operation == 'Adjustment' and not _is_opening(m):
            adj_refs[m.product_id].add(m.reference)

    last_outbound = {}
    last_any = {}
    for m in all_moves:
        last_any[m.product_id] = m.at
        if m.to_location_id is None:
            last_outbound[m.product_id] = m.at

    def top(d, n=5):
        rows = [(products[pid], qty) for pid, qty in d.items() if pid in products and qty > 0]
        rows.sort(key=lambda r: -r[1])
        return [{'product': p, 'quantity': q} for p, q in rows[:n]]

    fast = top(delivered)
    slow = []
    for pid, p in products.items():
        oh = totals.get(pid, 0.0)
        if oh <= 0 or delivered.get(pid, 0) > 0:
            continue
        lo = last_outbound.get(pid)
        slow.append({'product': p, 'on_hand': oh,
                     'last_outbound': lo,
                     'days_since': (now - lo).days if lo else None,
                     'last_movement': last_any.get(pid)})
    slow.sort(key=lambda r: (r['days_since'] is not None, -(r['days_since'] or 0)))

    adjustment_freq = [{'product': products[pid], 'count': len(refs)}
                       for pid, refs in adj_refs.items() if pid in products]
    adjustment_freq.sort(key=lambda r: -r['count'])

    adj_docs = Adjustment.query.filter(Adjustment.created_at >= start).all()
    adj_doc_counts = defaultdict(int)
    for a in adj_docs:
        if a.title.startswith('Opening Stock'):
            continue
        adj_doc_counts[a.status] += 1

    # Daily movement series
    series = []
    by_day = defaultdict(lambda: {'inbound': 0.0, 'outbound': 0.0, 'transfer': 0.0})
    for m in window:
        key = m.at.date()
        if m.operation == 'Internal Transfer':
            by_day[key]['transfer'] += m.quantity
        elif m.from_location_id is None:
            by_day[key]['inbound'] += m.quantity
        elif m.to_location_id is None:
            by_day[key]['outbound'] += m.quantity
    for i in range(days, -1, -1):
        d = (now - timedelta(days=i)).date()
        v = by_day.get(d, {'inbound': 0.0, 'outbound': 0.0, 'transfer': 0.0})
        series.append({'date': d, **v})
    series_max = max([max(s['inbound'], s['outbound'], s['transfer']) for s in series] + [0])

    stock_by_status = defaultdict(int)
    for pid, p in products.items():
        stock_by_status[get_status(p, totals.get(pid, 0.0))] += 1

    return {
        'days': days,
        'total_stock': sum(totals.get(pid, 0.0) for pid in products),
        'sku_count': len(products),
        'stock_by_status': dict(stock_by_status),
        # No unit price / cost is captured anywhere in the data model, so stock value is unavailable.
        'stock_value': None,
        'fast_moving': fast,
        'slow_moving': slow[:5],
        'most_transferred': top(transferred),
        'most_received': top(received),
        'most_delivered': top(delivered),
        'adjustment_frequency': adjustment_freq[:5],
        'adjustment_doc_counts': dict(adj_doc_counts),
        'warehouses': warehouse_overview(bal=bal),
        'series': series,
        'series_max': series_max,
        'movement_count': len(window),
        'has_movement': any(s['inbound'] or s['outbound'] or s['transfer'] for s in series),
    }


# =========================================================================
# FORECASTING
# =========================================================================

def forecast_product(product, on_hand=None, now=None, moves=None):
    now = now or _now()
    if on_hand is None:
        on_hand = company_totals().get(product.id, 0.0)
    if moves is None:
        moves = StockMovement.query.filter_by(product_id=product.id).order_by(StockMovement.at.asc()).all()

    incoming = db.session.query(func.coalesce(func.sum(ReceiptItem.quantity), 0.0)).join(
        Receipt, Receipt.id == ReceiptItem.receipt_id).filter(
        ReceiptItem.product_id == product.id, Receipt.status.in_(('Waiting', 'Ready'))).scalar() or 0.0

    result = {
        'product': product, 'on_hand': on_hand, 'incoming': float(incoming),
        'sufficient': False, 'avg_daily': None, 'days_left': None, 'depletion_date': None,
        'suggested_reorder': None, 'events': 0, 'span_days': 0, 'confidence': None,
        'reason': 'Not enough historical data for forecasting.',
    }
    if not moves:
        return result

    window_start = now - timedelta(days=FORECAST_WINDOW_DAYS)
    first = moves[0].at
    start = max(first, window_start)
    span_days = max(0.0, (now - start).total_seconds() / 86400.0)
    outbound = [m for m in moves if m.to_location_id is None and m.at >= start]
    events = len({m.reference for m in outbound})
    out_qty = sum(m.quantity for m in outbound)
    result['events'] = events
    result['span_days'] = int(span_days)

    if span_days < FORECAST_MIN_SPAN_DAYS or events < FORECAST_MIN_EVENTS or out_qty <= 0:
        result['reason'] = (f"Not enough historical data for forecasting "
                            f"({events} outbound event(s) over {int(span_days)} day(s); "
                            f"needs {FORECAST_MIN_EVENTS}+ events over {FORECAST_MIN_SPAN_DAYS}+ days).")
        return result

    avg = out_qty / span_days
    days_left = on_hand / avg if avg > 0 else None
    target = avg * FORECAST_COVER_DAYS + product.reorder_level
    suggested = max(0, math.ceil(target - on_hand - incoming))
    if events >= 10 and span_days >= 28:
        conf = 'High'
    elif events >= 6 and span_days >= 21:
        conf = 'Medium'
    else:
        conf = 'Low'
    result.update({
        'sufficient': True, 'avg_daily': avg, 'days_left': days_left,
        'depletion_date': (now + timedelta(days=days_left)) if days_left is not None else None,
        'suggested_reorder': suggested, 'confidence': conf, 'reason': None,
    })
    return result


def forecast_all():
    totals = company_totals()
    moves_by_product = defaultdict(list)
    for m in StockMovement.query.order_by(StockMovement.at.asc()).all():
        moves_by_product[m.product_id].append(m)
    now = _now()
    rows = [forecast_product(p, totals.get(p.id, 0.0), now, moves_by_product.get(p.id, []))
            for p in Product.query.filter_by(archived=False).order_by(Product.name).all()]
    rows.sort(key=lambda r: (not r['sufficient'], r['days_left'] if r['days_left'] is not None else 1e9))
    return rows


# =========================================================================
# AUDIT TRAIL (ledger replay + activity log — no duplicate audit store)
# =========================================================================

def _doc_reason_lookup():
    transfers = {t.id: t for t in Transfer.query.all()}
    return transfers


def audit_entries():
    """
    Builds audit entries from the ledger. Previous/new quantities are derived by
    replaying the StockMovement ledger in time order per (product, location).
    """
    transfers = _doc_reason_lookup()
    balance = defaultdict(float)
    entries = []
    moves = StockMovement.query.order_by(StockMovement.at.asc(), StockMovement.id.asc()).all()
    for m in moves:
        p = m.product
        changes = []
        if m.from_location_id is not None:
            key = (m.product_id, m.from_location_id)
            prev = balance[key]
            balance[key] = prev - m.quantity
            changes.append({'location': m.from_location, 'prev': prev, 'new': balance[key]})
        if m.to_location_id is not None:
            key = (m.product_id, m.to_location_id)
            prev = balance[key]
            balance[key] = prev + m.quantity
            changes.append({'location': m.to_location, 'prev': prev, 'new': balance[key]})

        if m.operation == 'Internal Transfer':
            t = transfers.get(m.doc_id)
            reason = t.reason if t and t.reason else None
            action = f"Transferred {m.quantity:g} {p.uom}"
        elif m.operation == 'Adjustment':
            reason = m.counterparty
            sign = '+' if m.to_location_id else '-'
            action = f"Adjusted quantity ({sign}{m.quantity:g} {p.uom})"
        elif m.operation == 'Receipt':
            reason = f"Supplier: {m.counterparty}" if m.counterparty else None
            action = f"Received {m.quantity:g} {p.uom}"
        else:
            reason = f"Customer: {m.counterparty}" if m.counterparty else None
            action = f"Delivered {m.quantity:g} {p.uom}"

        entries.append({
            'kind': 'stock', 'at': m.at, 'user': m.user, 'action': action,
            'operation': m.operation, 'reference': m.reference, 'doc_type': m.doc_type,
            'doc_id': m.doc_id, 'product': p, 'quantity': m.quantity,
            'from_location': m.from_location, 'to_location': m.to_location,
            'changes': changes, 'reason': reason, 'movement_id': m.id,
        })

    for log in ActivityLog.query.all():
        entries.append({
            'kind': 'document', 'at': log.at, 'user': log.user, 'action': log.action,
            'operation': log.doc_type, 'reference': None, 'doc_type': log.doc_type,
            'doc_id': log.doc_id, 'product': None, 'quantity': None,
            'from_location': None, 'to_location': None, 'changes': [],
            'reason': log.note, 'movement_id': None,
        })

    entries.sort(key=lambda e: e['at'], reverse=True)
    return entries


def movement_balance_changes(product_id):
    """Per-movement running balances for one product (used by the product timeline)."""
    balance = defaultdict(float)
    total = 0.0
    out = {}
    for m in StockMovement.query.filter_by(product_id=product_id).order_by(
            StockMovement.at.asc(), StockMovement.id.asc()).all():
        before_total = total
        if m.from_location_id is not None:
            balance[m.from_location_id] -= m.quantity
        if m.to_location_id is not None:
            balance[m.to_location_id] += m.quantity
        if m.from_location_id is None:
            total += m.quantity
        if m.to_location_id is None:
            total -= m.quantity
        out[m.id] = {'total_before': before_total, 'total_after': total}
    return out


# =========================================================================
# ANOMALY DETECTION (advisory only — never blocks an operation)
# =========================================================================

def _percentile(sorted_vals, q):
    if not sorted_vals:
        return None
    k = (len(sorted_vals) - 1) * q
    f, c = math.floor(k), math.ceil(k)
    if f == c:
        return sorted_vals[int(k)]
    return sorted_vals[f] + (sorted_vals[c] - sorted_vals[f]) * (k - f)


def baseline(samples):
    """Robust baseline from historical quantities, or None if too few samples."""
    if len(samples) < ANOMALY_MIN_SAMPLES:
        return None
    vals = sorted(samples)
    med = statistics.median(vals)
    mad = statistics.median([abs(v - med) for v in vals])
    return {'median': med, 'mad': mad, 'p25': _percentile(vals, 0.25),
            'p75': _percentile(vals, 0.75), 'n': len(vals)}


def is_unusual(qty, base):
    if not base or base['median'] <= 0:
        return False
    if base['mad'] > 0:
        robust_z = (qty - base['median']) / (1.4826 * base['mad'])
        return robust_z > 4 and qty > 2 * base['median']
    return qty > 3 * base['median']


def _history_samples(operation, product_id=None, before=None, exclude_ids=()):
    q = StockMovement.query.filter(StockMovement.operation == operation)
    if product_id:
        q = q.filter(StockMovement.product_id == product_id)
    if before:
        q = q.filter(StockMovement.at < before)
    rows = q.all()
    return [m.quantity for m in rows if m.id not in exclude_ids and not _is_opening(m)]


def check_quantity(operation, product_id, qty, before=None, exclude_ids=()):
    """
    Returns an advisory dict if qty is unusual versus history, else None.
    Uses product-level history when available, otherwise operation-wide history.
    """
    samples = _history_samples(operation, product_id, before, exclude_ids)
    scope = 'this product'
    base = baseline(samples)
    if not base:
        samples = _history_samples(operation, None, before, exclude_ids)
        base = baseline(samples)
        scope = f'all {operation.lower()}s'
    if not base:
        return None
    if is_unusual(qty, base):
        return {'quantity': qty, 'typical_low': base['p25'], 'typical_high': base['p75'],
                'median': base['median'], 'samples': base['n'], 'scope': scope}
    return None


def detect_anomalies(days=60):
    now = _now()
    start = now - timedelta(days=days)
    findings = []
    moves = StockMovement.query.order_by(StockMovement.at.asc(), StockMovement.id.asc()).all()

    # 1. Unusually large completed movements
    for m in moves:
        if m.at < start or _is_opening(m) or m.operation == 'Receipt':
            continue
        adv = check_quantity(m.operation, m.product_id, m.quantity, before=m.at, exclude_ids=(m.id,))
        if adv:
            kind = {'Internal Transfer': 'Large transfer', 'Adjustment': 'Large adjustment',
                    'Delivery': 'Large delivery'}.get(m.operation, 'Unusual movement')
            findings.append({
                'kind': kind, 'at': m.at, 'product': m.product, 'reference': m.reference,
                'doc_type': m.doc_type, 'doc_id': m.doc_id, 'user': m.user,
                'message': (f"{m.quantity:g} {m.product.uom} {m.operation.lower()} recorded. "
                            f"Typical {adv['scope']}: {adv['typical_low']:g}–{adv['typical_high']:g} "
                            f"{m.product.uom} (median {adv['median']:g}, {adv['samples']} samples)."),
                'pending': False,
            })

    # 2. Pending documents that would be unusual if completed
    for t in Transfer.query.filter(Transfer.status.in_(PENDING_TRANSFER_STATUSES)).all():
        for it in t.items:
            adv = check_quantity('Internal Transfer', it.product_id, it.quantity)
            if adv:
                findings.append({
                    'kind': 'Large transfer (pending)', 'at': t.created_at, 'product': it.product,
                    'reference': t.reference, 'doc_type': 'Internal Transfer', 'doc_id': t.id,
                    'user': t.creator,
                    'message': (f"{it.quantity:g} {it.product.uom} scheduled for transfer. "
                                f"Typical {adv['scope']}: {adv['typical_low']:g}–{adv['typical_high']:g} {it.product.uom}."),
                    'pending': True,
                })
    for a in Adjustment.query.filter_by(status='Counted').all():
        for it in a.items:
            diff = abs((it.counted_quantity or 0) - (it.system_quantity or 0))
            if diff <= 0:
                continue
            adv = check_quantity('Adjustment', it.product_id, diff)
            if adv:
                findings.append({
                    'kind': 'Large adjustment (pending approval)', 'at': a.counted_at or a.created_at,
                    'product': it.product, 'reference': a.reference, 'doc_type': 'Adjustment',
                    'doc_id': a.id, 'user': a.counter,
                    'message': (f"Count variance of {diff:g} {it.product.uom} awaiting approval. "
                                f"Typical {adv['scope']}: {adv['typical_low']:g}–{adv['typical_high']:g} {it.product.uom}."),
                    'pending': True,
                })

    # 3. Repeated adjustments on the same product
    repeat_start = now - timedelta(days=ANOMALY_REPEAT_ADJ_DAYS)
    adj_by_product = defaultdict(set)
    for m in moves:
        if m.operation == 'Adjustment' and not _is_opening(m) and m.at >= repeat_start:
            adj_by_product[m.product_id].add(m.reference)
    for pid, refs in adj_by_product.items():
        if len(refs) >= ANOMALY_REPEAT_ADJ_COUNT:
            p = Product.query.get(pid)
            findings.append({
                'kind': 'Repeated adjustments', 'at': now, 'product': p, 'reference': ', '.join(sorted(refs)),
                'doc_type': None, 'doc_id': None, 'user': None,
                'message': f"{len(refs)} stock adjustments on {p.name} in the last {ANOMALY_REPEAT_ADJ_DAYS} days.",
                'pending': False,
            })

    # 4. Sudden stock changes: an adjustment moving a location balance by a large share
    balance = defaultdict(float)
    for m in moves:
        prev_from = balance[(m.product_id, m.from_location_id)] if m.from_location_id else None
        if m.from_location_id is not None:
            balance[(m.product_id, m.from_location_id)] -= m.quantity
        if m.to_location_id is not None:
            balance[(m.product_id, m.to_location_id)] += m.quantity
        if m.at < start or m.operation != 'Adjustment' or _is_opening(m):
            continue
        loc = m.from_location or m.to_location
        prev = prev_from if m.from_location_id else balance[(m.product_id, m.to_location_id)] - m.quantity
        if prev and prev > 0:
            pct = m.quantity / prev * 100.0
            if pct >= ANOMALY_SUDDEN_CHANGE_PCT:
                findings.append({
                    'kind': 'Sudden stock change', 'at': m.at, 'product': m.product,
                    'reference': m.reference, 'doc_type': 'Adjustment', 'doc_id': m.doc_id, 'user': m.user,
                    'message': (f"Adjustment changed {m.product.name} at {loc.code} by {pct:.0f}% "
                                f"({prev:g} → {prev + (m.quantity if m.to_location_id else -m.quantity):g} {m.product.uom})."),
                    'pending': False,
                })

    findings.sort(key=lambda f: f['at'], reverse=True)
    return findings


# =========================================================================
# ALERT CENTER
# =========================================================================

SEVERITY_ORDER = {'critical': 0, 'warning': 1, 'info': 2}


def build_alerts(user):
    """Generates alerts from live data. Staff receive the subset relevant to floor work."""
    manager = user.is_manager
    alerts = []

    def add(severity, category, title, message, url, at=None):
        alerts.append({'severity': severity, 'category': category, 'title': title,
                       'message': message, 'url': url, 'at': at})

    bal = location_balances()
    totals = company_totals(bal)

    # Stock levels
    for p in Product.query.filter_by(archived=False).order_by(Product.name).all():
        oh = totals.get(p.id, 0.0)
        st = get_status(p, oh)
        if st == 'Out of Stock':
            add('critical', 'Stock', f"Out of stock: {p.name}",
                f"{p.name} ({p.sku}) has 0 {p.uom} on hand. Reorder level: {p.reorder_level} {p.uom}.",
                f"/products/{p.id}")
        elif st == 'Low Stock':
            add('warning', 'Stock', f"Low stock: {p.name}",
                f"{p.name} are below reorder level ({oh:g} / {p.reorder_level} {p.uom}).",
                f"/products/{p.id}")

    # Receipts
    for r in Receipt.query.filter(Receipt.status.in_(('Waiting', 'Ready'))).order_by(Receipt.scheduled_date).all():
        if r.status == 'Ready' and manager:
            add('warning', 'Receipts', f"Receipt {r.reference} is waiting for validation",
                f"Goods from {r.supplier.name} received; validate to post stock into {r.destination_location.code}.",
                f"/receipts/{r.id}", r.created_at)
        elif r.status == 'Waiting':
            add('info', 'Receipts', f"Receipt {r.reference} awaiting arrival",
                f"Supplier {r.supplier.name} → {r.destination_location.code}"
                + (f", scheduled {r.scheduled_date.strftime('%b %d')}" if r.scheduled_date else ''),
                f"/receipts/{r.id}", r.created_at)

    # Deliveries
    for d in Delivery.query.filter(Delivery.status.in_(('Waiting', 'Ready', 'Picked', 'Packed'))).all():
        if d.status == 'Packed' and manager:
            add('warning', 'Deliveries', f"Delivery Order {d.reference} is waiting for validation",
                f"Packed for {d.customer.name}; dispatch sign-off required.", f"/delivery-orders/{d.id}", d.created_at)
        elif d.status == 'Waiting' and manager:
            add('critical' if d.priority == 'Urgent' else 'warning', 'Deliveries',
                f"Delivery Order {d.reference} blocked by stock shortage",
                f"{d.customer.name} ({d.priority}) cannot be fulfilled from {d.source_location.code}.",
                f"/delivery-orders/{d.id}", d.created_at)
        elif d.status in ('Ready', 'Picked'):
            sev = 'warning' if d.priority == 'Urgent' else 'info'
            add(sev, 'Deliveries', f"Delivery Order {d.reference} ready to {'pick' if d.status == 'Ready' else 'pack'}",
                f"{d.customer.name} · {d.priority} · from {d.source_location.code}", f"/delivery-orders/{d.id}", d.created_at)

    # Transfers
    for t in Transfer.query.filter_by(status='Ready').all():
        add('info', 'Transfers', f"Transfer {t.reference} ready to move",
            f"{t.source_location.code} → {t.destination_location.code}", f"/internal-transfers/{t.id}", t.created_at)

    # Adjustments / approvals
    if manager:
        for a in Adjustment.query.filter_by(status='Counted').all():
            add('warning', 'Approvals', f"Adjustment {a.reference} pending approval",
                f"{a.title} — counted by {a.counter.name if a.counter else 'staff'}.",
                f"/inventory-adjustments/{a.id}", a.counted_at)
    for a in Adjustment.query.filter_by(status='Draft').all():
        if manager or a.assigned_to in (None, user.id):
            add('info', 'Counting', f"Count sheet {a.reference} awaiting count",
                a.title, f"/inventory-adjustments/{a.id}", a.created_at)

    # Capacity
    for w in warehouse_overview(bal=bal):
        u = w['util']
        if u['configured'] and u['level'] in ('warning', 'critical'):
            add(u['level'], 'Capacity', f"{w['name']} has reached {u['pct']:.0f}% capacity",
                f"{w['stock']:g} / {w['capacity']:g} units used.", f"/warehouses/{w['id']}")
        for loc in w['locations']:
            lu = loc['util']
            if lu['configured'] and lu['level'] in ('warning', 'critical'):
                add(lu['level'], 'Capacity', f"{loc['code']} is at {lu['pct']:.0f}% capacity",
                    f"{loc['used']:g} / {loc['capacity']:g} units in {loc['name']}.", f"/warehouses/{w['id']}?location={loc['id']}")

    if manager:
        # Forecast depletion
        for f in forecast_all():
            if f['sufficient'] and f['days_left'] is not None and f['days_left'] <= FORECAST_ALERT_DAYS and f['on_hand'] > 0:
                add('warning', 'Forecast', f"{f['product'].name} may run out in ~{f['days_left']:.0f} days",
                    f"Average usage {f['avg_daily']:.1f} {f['product'].uom}/day; suggested reorder {f['suggested_reorder']} {f['product'].uom}.",
                    f"/products/{f['product'].id}")
        # Anomalies
        for a in detect_anomalies():
            url = None
            if a['doc_type'] == 'Internal Transfer':
                url = f"/internal-transfers/{a['doc_id']}"
            elif a['doc_type'] == 'Adjustment':
                url = f"/inventory-adjustments/{a['doc_id']}"
            elif a['doc_type'] == 'Delivery':
                url = f"/delivery-orders/{a['doc_id']}"
            elif a['product']:
                url = f"/products/{a['product'].id}"
            add('warning', 'Unusual activity', f"Unusual activity detected: {a['kind']}",
                a['message'], url or '/anomalies', a['at'])

    alerts.sort(key=lambda a: (SEVERITY_ORDER[a['severity']], -(a['at'].timestamp() if a['at'] else 0)))
    return alerts
