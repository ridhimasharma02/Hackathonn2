"""
"Ask StockSense" — inventory assistant.

Architecture
------------
1. DATA-QUERY LAYER (`TOOLS`): small, read-only functions that answer
   factual questions straight from the ledger / documents. Each returns a
   structured result: {"answer": str, "columns": [...], "rows": [...], "links": [...]}.
   They never invent data; if nothing matches they say so.

2. ROUTER: a deterministic intent matcher that maps a natural-language
   question onto one of the tools. This works with no external service.

3. PROVIDER HOOK: an optional LLM provider can be registered with
   `register_provider()`. A provider receives the question plus the tool
   catalogue (name, description, parameters) and a `call_tool` callback, and
   must ground its answer in tool results. No provider is configured by
   default, so the app never needs an API key to run.

Role enforcement: tools flagged `manager_only` are refused for staff.
"""
import difflib
import re
from datetime import datetime, timedelta

from models import db, Product, Warehouse, Location, Delivery, Receipt, StockMovement
from services.stock_engine import get_status
from services import insights


# ---------------------------------------------------------------------------
# Entity resolution helpers
# ---------------------------------------------------------------------------

def _norm(s):
    return re.sub(r'[^a-z0-9 ]+', ' ', (s or '').lower()).strip()


def find_product(question):
    q = _norm(question)
    products = Product.query.filter_by(archived=False).all()
    for p in products:  # exact SKU
        if re.search(r'\b' + re.escape(p.sku.lower()) + r'\b', q):
            return p
    best, best_score = None, 0.0
    for p in products:
        name = _norm(p.name)
        singular = name[:-1] if name.endswith('s') else name
        if name in q or singular in q:
            score = len(name)
            if score > best_score:
                best, best_score = p, score
    if best:
        return best
    words = q.split()
    names = {_norm(p.name): p for p in products}
    for n in range(3, 0, -1):
        for i in range(len(words) - n + 1):
            chunk = ' '.join(words[i:i + n])
            match = difflib.get_close_matches(chunk, names.keys(), n=1, cutoff=0.8)
            if match:
                return names[match[0]]
    return None


def find_warehouse(question):
    q = _norm(question)
    whs = Warehouse.query.filter_by(active=True).all()
    for w in whs:
        if re.search(r'\b' + re.escape(w.code.lower()) + r'\b', q):
            return w
    for w in sorted(whs, key=lambda w: -len(w.name)):
        if _norm(w.name) in q:
            return w
    m = re.search(r'warehouse\s*(\d+)', q)
    if m:
        for w in whs:
            if w.code.lower() in (f"wh{m.group(1)}", f"w{m.group(1)}") or _norm(w.name) == f"warehouse {m.group(1)}":
                return w
    if re.search(r'\bmain\b', q):
        for w in whs:
            if 'main' in w.name.lower() or w.code.upper() == 'MAIN':
                return w
    return None


def _fmt(v):
    return f"{v:g}" if isinstance(v, (int, float)) else str(v)


# ---------------------------------------------------------------------------
# Data-query layer (tools)
# ---------------------------------------------------------------------------

def tool_low_stock(warehouse=None):
    bal = insights.location_balances()
    totals = insights.company_totals(bal)
    loc_wh = {l.id: l.warehouse_id for l in Location.query.all()}
    rows = []
    for p in Product.query.filter_by(archived=False).order_by(Product.name).all():
        total = totals.get(p.id, 0.0)
        st = get_status(p, total)
        if st == 'In Stock':
            continue
        if warehouse:
            wh_qty = sum(q for (pid, lid), q in bal.items()
                         if pid == p.id and loc_wh.get(lid) == warehouse.id)
            if wh_qty <= 0 and st == 'Low Stock':
                continue  # not stocked in this warehouse
            rows.append([p.name, p.sku, _fmt(wh_qty) + ' ' + p.uom, _fmt(total) + ' ' + p.uom, str(p.reorder_level), st])
        else:
            rows.append([p.name, p.sku, _fmt(total) + ' ' + p.uom, str(p.reorder_level), st])
    scope = f" in {warehouse.name}" if warehouse else ''
    if not rows:
        return {'answer': f"No products are low or out of stock{scope}.", 'columns': [], 'rows': []}
    cols = (['Product', 'SKU', f'Qty in {warehouse.code}', 'Company total', 'Reorder level', 'Status']
            if warehouse else ['Product', 'SKU', 'On hand', 'Reorder level', 'Status'])
    note = (" Status uses the company-wide reorder level." if warehouse else '')
    return {'answer': f"{len(rows)} product(s) are low or out of stock{scope}.{note}", 'columns': cols, 'rows': rows}


def tool_out_of_stock():
    totals = insights.company_totals()
    rows = [[p.name, p.sku, str(p.reorder_level) + ' ' + p.uom]
            for p in Product.query.filter_by(archived=False).order_by(Product.name).all()
            if totals.get(p.id, 0.0) <= 0]
    if not rows:
        return {'answer': "No products are currently out of stock.", 'columns': [], 'rows': []}
    return {'answer': f"{len(rows)} product(s) are out of stock.", 'columns': ['Product', 'SKU', 'Reorder level'], 'rows': rows}


def tool_stale_products(days=14):
    now = datetime.utcnow()
    totals = insights.company_totals()
    rows = []
    for p in Product.query.filter_by(archived=False).order_by(Product.name).all():
        last = StockMovement.query.filter_by(product_id=p.id).order_by(StockMovement.at.desc()).first()
        if last is None or last.at < now - timedelta(days=days):
            rows.append([p.name, p.sku, _fmt(totals.get(p.id, 0.0)) + ' ' + p.uom,
                         last.at.strftime('%Y-%m-%d') if last else 'Never moved'])
    if not rows:
        return {'answer': f"Every product has moved within the last {days} days.", 'columns': [], 'rows': []}
    return {'answer': f"{len(rows)} product(s) have had no stock movement in the last {days} days.",
            'columns': ['Product', 'SKU', 'On hand', 'Last movement'], 'rows': rows}


def tool_product_stock(product):
    bal = insights.location_balances()
    total = sum(q for (pid, _), q in bal.items() if pid == product.id)
    rows = []
    for (pid, lid), q in sorted(bal.items(), key=lambda kv: -kv[1]):
        if pid == product.id and abs(q) > 1e-9:
            loc = Location.query.get(lid)
            rows.append([loc.warehouse.name, loc.code, _fmt(q) + ' ' + product.uom])
    st = get_status(product, total)
    return {'answer': f"{_fmt(total)} {product.uom} of {product.name} ({product.sku}) are currently on hand — {st}.",
            'columns': ['Warehouse', 'Location', 'On hand'], 'rows': rows,
            'links': [{'label': f'Open {product.name}', 'url': f'/products/{product.id}'}]}


def tool_warehouse_ranking():
    data = insights.warehouse_overview()
    if not data:
        return {'answer': "No active warehouses are configured.", 'columns': [], 'rows': []}
    data.sort(key=lambda w: -w['stock'])
    rows = [[w['name'], w['code'], _fmt(w['stock']), str(w['product_count']),
             f"{w['util']['pct']:g}%" if w['util']['configured'] else 'Not set'] for w in data]
    top = data[0]
    return {'answer': f"{top['name']} holds the most stock ({_fmt(top['stock'])} units across {top['product_count']} products).",
            'columns': ['Warehouse', 'Code', 'Units on hand', 'Products', 'Utilization'], 'rows': rows,
            'links': [{'label': 'Open warehouse map', 'url': '/warehouses'}]}


def tool_pending_deliveries():
    ds = Delivery.query.filter(Delivery.status.in_(insights.PENDING_DELIVERY_STATUSES)).order_by(Delivery.scheduled_date).all()
    if not ds:
        return {'answer': "There are no pending delivery orders.", 'columns': [], 'rows': []}
    rows = [[d.reference, d.customer.name, d.status, d.priority, d.source_location.code,
             d.scheduled_date.strftime('%Y-%m-%d') if d.scheduled_date else '—'] for d in ds]
    return {'answer': f"{len(ds)} delivery order(s) are pending.",
            'columns': ['Reference', 'Customer', 'Status', 'Priority', 'Source', 'Scheduled'], 'rows': rows,
            'links': [{'label': d.reference, 'url': f'/delivery-orders/{d.id}'} for d in ds[:6]]}


def tool_pending_receipts():
    rs = Receipt.query.filter(Receipt.status.in_(insights.PENDING_RECEIPT_STATUSES)).order_by(Receipt.scheduled_date).all()
    if not rs:
        return {'answer': "There are no pending receipts.", 'columns': [], 'rows': []}
    rows = [[r.reference, r.supplier.name, r.status, r.destination_location.code,
             r.scheduled_date.strftime('%Y-%m-%d') if r.scheduled_date else '—'] for r in rs]
    return {'answer': f"{len(rs)} receipt(s) are pending.",
            'columns': ['Reference', 'Supplier', 'Status', 'Destination', 'Scheduled'], 'rows': rows,
            'links': [{'label': r.reference, 'url': f'/receipts/{r.id}'} for r in rs[:6]]}


def tool_utilization():
    data = insights.warehouse_overview()
    rows = [[w['name'], _fmt(w['stock']), _fmt(w['capacity']) if w['capacity'] else 'Not set',
             f"{w['util']['pct']:g}%" if w['util']['configured'] else '—', w['util']['status']] for w in data]
    return {'answer': "Current warehouse utilization:", 'columns': ['Warehouse', 'Used', 'Capacity', 'Utilization', 'Status'], 'rows': rows}


def tool_forecast(product):
    f = insights.forecast_product(product)
    if not f['sufficient']:
        return {'answer': f"{product.name}: {f['reason']}", 'columns': [], 'rows': []}
    return {'answer': (f"{product.name}: current stock {_fmt(f['on_hand'])} {product.uom}, average daily usage "
                       f"{f['avg_daily']:.1f} {product.uom}. Estimated depletion in ~{f['days_left']:.0f} days "
                       f"(confidence: {f['confidence']}). Suggested reorder: {f['suggested_reorder']} {product.uom}."),
            'columns': [], 'rows': []}


TOOLS = {
    'low_stock': {'fn': tool_low_stock, 'description': 'Products at or below reorder level, optionally in one warehouse.',
                  'params': {'warehouse': 'optional warehouse'}},
    'out_of_stock': {'fn': tool_out_of_stock, 'description': 'Products with zero stock.', 'params': {}},
    'stale_products': {'fn': tool_stale_products, 'description': 'Products with no movement in N days.', 'params': {'days': 'int'}},
    'product_stock': {'fn': tool_product_stock, 'description': 'Current stock of a product by location.', 'params': {'product': 'product'}},
    'warehouse_ranking': {'fn': tool_warehouse_ranking, 'description': 'Warehouses ranked by stock held.', 'params': {}},
    'pending_deliveries': {'fn': tool_pending_deliveries, 'description': 'Open delivery orders.', 'params': {}},
    'pending_receipts': {'fn': tool_pending_receipts, 'description': 'Open receipts.', 'params': {}},
    'utilization': {'fn': tool_utilization, 'description': 'Warehouse capacity utilization.', 'params': {}},
    'forecast': {'fn': tool_forecast, 'description': 'Depletion forecast for a product.', 'params': {'product': 'product'},
                 'manager_only': True},
}


# ---------------------------------------------------------------------------
# Optional LLM provider hook
# ---------------------------------------------------------------------------

_provider = None


def register_provider(provider):
    """
    Register an object with `answer(question, tools, call_tool, user) -> dict | None`.
    `tools` is the catalogue (name -> description/params); `call_tool(name, **kwargs)`
    executes a data-query tool with role checks applied. Return None to fall back
    to the built-in router.
    """
    global _provider
    _provider = provider


def provider_name():
    return type(_provider).__name__ if _provider else None


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def _call(name, user, **kwargs):
    spec = TOOLS[name]
    if spec.get('manager_only') and not user.is_manager:
        return {'answer': "That information is available to Inventory Managers only.", 'columns': [], 'rows': []}
    return spec['fn'](**kwargs)


def route(question):
    q = _norm(question)
    product = find_product(question)
    warehouse = find_warehouse(question)

    if re.search(r'forecast|run out|deplet|last how long|how long will', q):
        return ('forecast', {'product': product}) if product else None
    if re.search(r'out of stock|zero stock|no stock|stockout|stock out', q):
        return ('out_of_stock', {})
    if re.search(r'\blow\b|reorder|running low|below', q):
        return ('low_stock', {'warehouse': warehouse})
    if re.search(r"haven t moved|not moved|hasn t moved|no movement|stale|slow|idle|dead stock|not moving", q):
        m = re.search(r'(\d+)\s*day', q)
        return ('stale_products', {'days': int(m.group(1)) if m else 14})
    if re.search(r'pending deliver|open deliver|delivery orders|deliveries|dispatch', q):
        return ('pending_deliveries', {})
    if re.search(r'pending receipt|open receipt|receipts|incoming|inbound', q):
        return ('pending_receipts', {})
    if re.search(r'utili[sz]ation|capacity|how full|space', q):
        return ('utilization', {})
    if re.search(r'(most|highest|largest|biggest) stock|which warehouse', q):
        return ('warehouse_ranking', {})
    if product and re.search(r'how much|how many|available|stock|on hand|quantity|where', q):
        return ('product_stock', {'product': product})
    if product:
        return ('product_stock', {'product': product})
    return None


SUGGESTIONS = [
    "Which products are low in Warehouse 2?",
    "Which products are out of stock?",
    "Which products haven't moved recently?",
    "How much Steel Rod is currently available?",
    "Which warehouse has the most stock?",
    "Show pending deliveries.",
]


def ask(question, user):
    question = (question or '').strip()
    if not question:
        return {'answer': 'Please type a question about your inventory.', 'columns': [], 'rows': [], 'intent': None}

    if _provider is not None:
        catalogue = {k: {'description': v['description'], 'params': v['params']} for k, v in TOOLS.items()
                     if user.is_manager or not v.get('manager_only')}
        try:
            res = _provider.answer(question, catalogue, lambda name, **kw: _call(name, user, **kw), user)
            if res:
                res.setdefault('intent', 'provider')
                return res
        except Exception:  # provider failures must never break the assistant
            pass

    routed = route(question)
    if not routed:
        return {'answer': ("I couldn't match that question to inventory data. Try asking about low or out-of-stock "
                           "products, a product's current stock, pending deliveries or receipts, warehouse stock or "
                           "utilization, or products that haven't moved."),
                'columns': [], 'rows': [], 'intent': None}
    name, kwargs = routed
    res = _call(name, user, **kwargs)
    res.setdefault('links', [])
    res['intent'] = name
    return res
