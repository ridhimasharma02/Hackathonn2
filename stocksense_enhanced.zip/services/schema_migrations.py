"""
Lightweight, additive schema upgrades for existing StockSense databases.

The project uses db.create_all() (no Alembic). create_all() never alters
existing tables, so databases created before the capacity / map fields were
introduced would be missing those columns. This helper adds any missing
nullable columns in place. It never drops or rewrites data.
"""
from sqlalchemy import inspect, text

# table -> [(column, SQL type)] ; all columns are nullable
ADDITIVE_COLUMNS = {
    'warehouses': [
        ('capacity', 'FLOAT'),
        ('latitude', 'FLOAT'),
        ('longitude', 'FLOAT'),
    ],
    'locations': [
        ('capacity', 'FLOAT'),
        ('location_type', 'VARCHAR(30)'),
    ],
}


def ensure_additive_columns(db):
    engine = db.engine
    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())
    with engine.begin() as conn:
        for table, columns in ADDITIVE_COLUMNS.items():
            if table not in existing_tables:
                continue  # create_all() will build it with all columns
            present = {c['name'] for c in inspector.get_columns(table)}
            for name, sql_type in columns:
                if name not in present:
                    conn.execute(text(f'ALTER TABLE {table} ADD COLUMN {name} {sql_type}'))
