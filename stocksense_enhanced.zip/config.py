import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'stocksense-enterprise-secret-key-2026')
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'stocksense.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = None
    # Warehouse map tiles. OpenStreetMap needs no API key; point these at any
    # XYZ tile provider (Mapbox, MapTiler, self-hosted) to switch providers.
    # Set MAP_TILE_URL to an empty string to always use the offline schematic map.
    MAP_TILE_URL = os.environ.get('MAP_TILE_URL', 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png')
    MAP_TILE_ATTRIBUTION = os.environ.get('MAP_TILE_ATTRIBUTION', '&copy; OpenStreetMap contributors')

from sqlalchemy.pool import StaticPool

class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite://'
    SQLALCHEMY_ENGINE_OPTIONS = {
        'connect_args': {'check_same_thread': False},
        'poolclass': StaticPool
    }
    WTF_CSRF_ENABLED = False
    SERVER_NAME = 'localhost'

