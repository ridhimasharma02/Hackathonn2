# StockSense — Enterprise Inventory & Warehouse Management System

StockSense is a high-performance inventory and warehouse management system built with **Python 3.11+**, **Flask 3**, **SQLAlchemy**, and **SQLite**. The frontend strictly adheres to the design exported from **Google Stitch** (preserving all Tailwind utilities, typography, component hierarchies, spacing, and colors with zero UI deviations).

---

## Key Highlights & Architecture

- **Strict Rule 1 Adherence**: Frontend uses the Google Stitch exported HTML screens. Only hardcoded sample data was replaced with Jinja2 loops and context variables, and functional attributes (`form`, `method`, `action`, CSRF tokens, `data-*`, and minimal vanilla JS) were wired in.
- **Stock is Computed, Never Stored on Product**: On-hand stock at any warehouse location is computed dynamically from the immutable ledger:
  $$\text{On-Hand} = \sum (\text{Movements In}) - \sum (\text{Movements Out})$$
  All stock logic is isolated in `services/stock_engine.py`.
- **Server-Enforced RBAC**: Strict role-based access control guards every route (`@require_permission`) and service mutation (`check_permission`). Unauthorized actions immediately return `HTTP 403 Access Denied`.
- **Transactional State Machines**: Receipts, deliveries, transfers, and physical cycle count adjustments are atomic operations with comprehensive validation.

---

## Warehouse Intelligence (v2 enhancements)

All new features read the **same stock ledger** as the rest of the app (`services/insights.py`); nothing keeps a second copy of inventory.

| Feature | Route | Manager | Staff |
| :--- | :--- | :---: | :---: |
| Warehouse Map (OpenStreetMap tiles, no API key; offline schematic fallback) | `/warehouses` | Yes | Yes |
| Floor / Rack Layout + capacity per location | `/warehouses/<id>` | Yes (+ edit capacity) | View |
| Transfer Tracking + ledger postings on transfer detail | `/internal-transfers/tracking` | Yes | Yes |
| Alert Center (critical / warning / info), also powers the topbar bell | `/alerts` | All alerts | Floor-relevant |
| Analytics | `/analytics` | Yes | 403 |
| Forecasting (only with ≥3 outbound events over ≥14 days) | `/forecasting` | Yes | 403 |
| Audit Trail (ledger replay: previous → new qty, user, reason) | `/audit-trail` | Yes | 403 |
| Anomaly Review (advisory only, never blocks) | `/anomalies` | Yes | 403 |
| Scan Product (camera via BarcodeDetector, manual/USB-scanner fallback) | `/scan` | Yes | Yes |
| Ask StockSense (built-in query engine; LLM hook: `services.assistant.register_provider`) | `/assistant` | Yes | Yes (no forecasts) |
| Global search: + warehouses, locations, ledger, supplier/customer names | topbar | Yes | Yes |

Configuration:
- `MAP_TILE_URL` / `MAP_TILE_ATTRIBUTION` env vars switch map provider; set `MAP_TILE_URL=""` to force the schematic map.
- Capacity is measured in stored units (mixed UoM). New nullable columns (`warehouses.capacity/latitude/longitude`, `locations.capacity/location_type`) are added automatically to existing databases at startup (`services/schema_migrations.py`).
- Stock value shows "No data available" because products carry no cost/price.

Tests: `PYTHONPATH=. pytest tests -v` (6 original + 23 enhancement tests).

---

## Demo Accounts

| Role | Name | Email | Password | Allowed Scope |
| :--- | :--- | :--- | :--- | :--- |
| **Inventory Manager** | Ridhima Sharma | `manager@stocksense.demo` | `Manager@2026` | Full system access: catalog, locations, receipts, deliveries, transfers, adjustments signoff, ledger export, settings. |
| **Warehouse Staff** | Aman Kumar | `staff@stocksense.demo` | `Staff@2026` | Floor tasks: receiving goods, picking, packing, internal relocations, blind cycle counting. |
| **Warehouse Staff** | Neha Joshi | `neha.joshi@stocksense.demo` | `Staff@2026` | Floor tasks: receiving goods, picking, packing, internal relocations, blind cycle counting. |

---

## Role & Permission Matrix

| Capability / Action | Inventory Manager | Warehouse Staff | Server Enforcement Guard |
| :--- | :---: | :---: | :--- |
| **View Dashboard & KPIs** | Yes | Yes (Task Queues) | `routes/dashboard.py` (role-specific views) |
| **Create / Edit Products** | Yes | No (403) | `@require_permission('products:create')` / `products:edit` |
| **Create Inward Receipts** | Yes | No (403) | `@require_permission('receipts:create')` |
| **Confirm Receipts** | Yes | No (403) | `@require_permission('receipts:confirm')` |
| **Receive Goods (Floor Tally)** | Yes | Yes | `services/inventory_service.py:receive_goods` |
| **Validate Receipts (Post Stock)** | Yes | No (403) | `@require_permission('receipts:validate')` |
| **Create Delivery Orders** | Yes | No (403) | `@require_permission('deliveries:create')` |
| **Confirm Deliveries** | Yes | No (403) | `@require_permission('deliveries:confirm')` |
| **Pick & Pack Deliveries** | Yes | Yes | `@require_permission('deliveries:pick')` / `deliveries:pack` |
| **Validate Dispatch (Post Stock)** | Yes | No (403) | `@require_permission('deliveries:validate')` |
| **Create & Move Transfers** | Yes | Yes | `@require_permission('transfers:create')` / `transfers:complete` |
| **Issue Count Sheets** | Yes | No (403) | `@require_permission('adjustments:create')` |
| **Submit Physical Blind Count** | Yes | Yes | `@require_permission('adjustments:count')` |
| **Approve / Reject Adjustments** | Yes | No (403) | `@require_permission('adjustments:approve')` |
| **Export Stock Ledger CSV** | Yes | No (403) | `@require_permission('history:export')` |
| **System Settings & Facilities** | Yes | No (403) | `@require_permission('settings:manage')` |

---

## Business Rules Summary

1. **Receipts (`REC-xxxx`)**:
   - `Draft` $\rightarrow$ `Waiting` $\rightarrow$ `Ready` $\rightarrow$ `Done`
   - Staff records received quantities on the floor. Stock **does not change** during receiving.
   - Manager validation increments on-hand stock and writes an immutable `StockMovement`.
2. **Deliveries (`DO-xxxx`)**:
   - `Draft` $\rightarrow$ `Waiting` $\rightarrow$ `Ready` $\rightarrow$ `Picked` $\rightarrow$ `Packed` $\rightarrow$ `Done`
   - If available stock is insufficient at the source location, order is set to `Waiting` and shows a red deficit table with requested, available, and shortage.
   - Dispatch validation deducts on-hand stock and prevents negative inventory.
3. **Internal Transfers (`INT-xxxx`)**:
   - Relocates stock between locations/bins. Company-wide stock remains unchanged. Source and destination must differ.
4. **Physical Adjustments (`ADJ-xxxx`)**:
   - Staff performs blind counts without seeing system quantities.
   - If a discrepancy exists, a reason (`Damaged`, `Missing`, `Counting Error`, `Found Stock`, `Other`) is strictly mandatory.
   - Submitting a count does not alter stock. Manager approval reconciles stock to the physical count and records variance in the ledger.

---

## Setup & Running Locally

### 1. Prerequisites
- Python 3.11+
- Virtual environment (`venv`)

### 2. Installation
```bash
# Clone or navigate to the project directory
cd stitch_stocksense_inventory_management_system

# Create and activate virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Database Seeding
StockSense includes a comprehensive seed script that generates 25 days of realistic warehouse transactions and sets up the required benchmark states:
```bash
flask --app app seed
```
This initializes `instance/stocksense.db` with:
- 3 User accounts
- 2 Warehouses (`MAIN`, `WH2`) and 5 Locations
- 8 Products with calibrated stock levels (1 out-of-stock, 2 low-stock, 5 in-stock)
- Realistic receipts, deliveries, transfers, adjustments, and move history ledger records

### 4. Running the Application
StockSense is configured to run on port **5001** (macOS reserves port 5000 for Apple AirPlay Receiver, which causes HTTP 403 errors on port 5000).

```bash
# Recommended: Quick launcher (auto-seeds if needed and launches browser)
python3 run.py

# Or run with Flask CLI (uses .flaskenv defaults):
flask run
```

Browse link: [http://localhost:5001](http://localhost:5001) or [http://127.0.0.1:5001](http://127.0.0.1:5001)

---

## Running Acceptance Tests

The test suite validates all acceptance requirements (manager lifecycle, staff RBAC restrictions, OTP reset, duplicate SKU handling, and stock non-negativity):
```bash
PYTHONPATH=. pytest tests/test_scenario.py -v
```

All 6 acceptance test scenarios pass.
