"""
Tests for the warehouse-intelligence enhancements. Every feature must read the
same ledger as the core inventory system and respect server-side RBAC.
"""
import io
import contextlib
from datetime import datetime, timedelta

import pytest
from sqlalchemy import create_engine, text

from app import create_app
from models import db, User, Product, Location, Warehouse, Supplier, Customer, Transfer, StockMovement
from services import inventory_service as inv
from services import insights, assistant
from services.stock_engine import get_on_hand
from seed import seed_database


@pytest.fixture(scope='function')
def test_app():
    app = create_app('config.TestConfig')
    with app.app_context():
        with contextlib.redirect_stdout(io.StringIO()):
            seed_database(app)
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(test_app):
    return test_app.test_client()


def login(client, email, password):
    client.get('/logout')
    return client.post('/login', data={'email': email, 'password': password}, follow_redirects=True)


def as_manager(client):
    return login(client, 'manager@stocksense.demo', 'Manager@2026')


def as_staff(client):
    return login(client, 'staff@stocksense.demo', 'Staff@2026')


def mgr():
    return User.query.filter_by(email='manager@stocksense.demo').first()


def staff():
    return User.query.filter_by(email='staff@stocksense.demo').first()


def loc(code):
    return Location.query.filter_by(code=code).first()


def prod(sku):
    return Product.query.filter_by(sku=sku).first()


# -------------------------------------------------------------------------
# Data consistency
# -------------------------------------------------------------------------

def test_bulk_balances_match_stock_engine(test_app):
    bal = insights.location_balances()
    totals = insights.company_totals(bal)
    for p in Product.query.all():
        assert abs(totals.get(p.id, 0.0) - get_on_hand(p.id)) < 1e-9
        for l in Location.query.all():
            assert abs(bal.get((p.id, l.id), 0.0) - get_on_hand(p.id, l.id)) < 1e-9


def test_transfer_completion_moves_stock_and_keeps_company_total(test_app):
    steel = prod('SR001')
    src, dst = loc('MAIN/STOCK'), loc('MAIN/RACK-A')
    total_before = get_on_hand(steel.id)
    src_before, dst_before = get_on_hand(steel.id, src.id), get_on_hand(steel.id, dst.id)
    moves_before = StockMovement.query.count()

    t = inv.create_transfer(src.id, dst.id, items=[{'product_id': steel.id, 'quantity': 50}], user=staff())
    inv.complete_transfer(t.id, user=staff())

    assert get_on_hand(steel.id, src.id) == src_before - 50
    assert get_on_hand(steel.id, dst.id) == dst_before + 50
    assert get_on_hand(steel.id) == total_before
    assert StockMovement.query.count() == moves_before + 1

    # Warehouse floor map reflects the new location balance
    w = insights.warehouse_overview(src.warehouse)[0]
    rack = next(l for l in w['locations'] if l['id'] == dst.id)
    assert any(p['product_id'] == steel.id and p['quantity'] == dst_before + 50 for p in rack['products'])

    # Audit trail shows previous -> new for both sides
    entry = next(e for e in insights.audit_entries() if e['kind'] == 'stock' and e['reference'] == t.reference)
    changes = {c['location'].code: (c['prev'], c['new']) for c in entry['changes']}
    assert changes['MAIN/STOCK'] == (src_before, src_before - 50)
    assert changes['MAIN/RACK-A'] == (dst_before, dst_before + 50)


def test_transfer_detail_shows_ledger_postings(client, test_app):
    steel = prod('SR001')
    t = inv.create_transfer(loc('MAIN/STOCK').id, loc('MAIN/RACK-B').id,
                            items=[{'product_id': steel.id, 'quantity': 5}], user=mgr())
    inv.complete_transfer(t.id, user=mgr())
    as_staff(client)
    res = client.get(f'/internal-transfers/{t.id}')
    assert res.status_code == 200
    assert b'Stock Ledger Postings' in res.data
    assert b'Company total unchanged' in res.data
    assert b'Aman Kumar' in res.data  # completer is now shown (was always blank)


# -------------------------------------------------------------------------
# RBAC
# -------------------------------------------------------------------------

@pytest.mark.parametrize('url', ['/analytics', '/forecasting', '/audit-trail', '/anomalies'])
def test_staff_blocked_from_manager_insights(client, test_app, url):
    as_staff(client)
    assert client.get(url).status_code == 403
    as_manager(client)
    assert client.get(url).status_code == 200


def test_staff_cannot_configure_capacity_via_direct_post(client, test_app):
    wh = Warehouse.query.filter_by(code='WH2').first()
    as_staff(client)
    res = client.post(f'/warehouses/{wh.id}/configure', data={'capacity': '5'})
    assert res.status_code == 403
    db.session.refresh(wh)
    assert wh.capacity == 400


def test_staff_floor_tools_available(client, test_app):
    as_staff(client)
    for url in ['/warehouses', '/alerts', '/scan', '/assistant', '/internal-transfers/tracking']:
        assert client.get(url).status_code == 200, url


def test_assistant_forecast_is_manager_only(test_app):
    res = assistant.ask('forecast steel rods', staff())
    assert 'Inventory Managers only' in res['answer']
    res = assistant.ask('forecast steel rods', mgr())
    assert 'Steel Rods' in res['answer']


# -------------------------------------------------------------------------
# Capacity
# -------------------------------------------------------------------------

def test_manager_configures_capacity_and_validation(client, test_app):
    wh = Warehouse.query.filter_by(code='MAIN').first()
    rack = loc('MAIN/RACK-A')
    as_manager(client)
    client.post(f'/warehouses/{wh.id}/configure', data={
        'capacity': '2000', 'latitude': '18.7', 'longitude': '73.8',
        f'loc_capacity_{rack.id}': '120', f'loc_type_{rack.id}': 'Rack'})
    db.session.refresh(wh)
    db.session.refresh(rack)
    assert wh.capacity == 2000 and rack.capacity == 120

    client.post(f'/warehouses/{wh.id}/configure', data={'capacity': '-1'})
    db.session.refresh(wh)
    assert wh.capacity == 2000  # rejected

    w = insights.warehouse_overview(wh)[0]
    assert w['util']['pct'] == round(w['stock'] / 2000 * 100, 1)


def test_capacity_status_levels():
    assert insights.capacity_status(10, None)['configured'] is False
    assert insights.capacity_status(50, 100)['level'] == 'ok'
    assert insights.capacity_status(85, 100)['level'] == 'warning'
    assert insights.capacity_status(96, 100)['level'] == 'critical'
    assert insights.capacity_status(120, 100)['status'] == 'Over capacity'


# -------------------------------------------------------------------------
# Alerts
# -------------------------------------------------------------------------

def test_alerts_from_live_data(test_app):
    alerts = insights.build_alerts(mgr())
    titles = [a['title'] for a in alerts]
    assert 'Out of stock: LED Panels' in titles
    assert 'Low stock: Aluminum Sheets' in titles
    assert any('Warehouse 2 has reached' in t for t in titles)
    assert any(t.startswith('Delivery Order DO-0006 is waiting for validation') for t in titles)
    staff_titles = [a['title'] for a in insights.build_alerts(staff())]
    assert not any('waiting for validation' in t for t in staff_titles)
    assert not any('pending approval' in t for t in staff_titles)


def test_notifications_endpoint_shape(client, test_app):
    as_manager(client)
    data = client.get('/notifications').get_json()
    assert set(data) == {'count', 'notifications'}
    assert data['count'] >= len(data['notifications'])
    assert all(n['type'] in ('error', 'warning', 'info') for n in data['notifications'])


# -------------------------------------------------------------------------
# Forecasting
# -------------------------------------------------------------------------

def test_forecast_insufficient_data_message(test_app):
    f = insights.forecast_product(prod('LP005'))
    assert f['sufficient'] is False
    assert 'Not enough historical data for forecasting' in f['reason']


def test_forecast_with_history(test_app):
    paper = prod('PP004')
    cust = Customer.query.first()
    src = loc('MAIN/STOCK')
    now = datetime.utcnow()
    for i in range(5):
        d = inv.create_delivery(cust.id, src.id, items=[{'product_id': paper.id, 'quantity': 10}], user=mgr())
        inv.confirm_delivery(d.id, user=mgr())
        inv.pick_delivery(d.id, user=mgr())
        inv.pack_delivery(d.id, user=mgr())
        inv.validate_delivery(d.id, user=mgr())
        StockMovement.query.filter_by(reference=d.reference).update({'at': now - timedelta(days=4 * i + 1)})
    db.session.commit()
    f = insights.forecast_product(paper)
    assert f['sufficient'] is True
    assert f['avg_daily'] > 0
    assert f['days_left'] == pytest.approx(f['on_hand'] / f['avg_daily'])
    assert f['suggested_reorder'] >= 0


# -------------------------------------------------------------------------
# Anomalies (advisory only)
# -------------------------------------------------------------------------

def test_large_transfer_is_flagged_but_not_blocked(test_app):
    steel = prod('SR001')
    a, b = loc('MAIN/STOCK'), loc('MAIN/RACK-A')
    for q in (8, 10, 12, 9, 11, 10):
        t = inv.create_transfer(a.id, b.id, items=[{'product_id': steel.id, 'quantity': q}], user=mgr())
        inv.complete_transfer(t.id, user=mgr())
    adv = insights.check_quantity('Internal Transfer', steel.id, 200)
    assert adv is not None and adv['typical_high'] < 200
    assert insights.check_quantity('Internal Transfer', steel.id, 11) is None

    big = inv.create_transfer(a.id, b.id, items=[{'product_id': steel.id, 'quantity': 200}], user=mgr())
    kinds = [f['kind'] for f in insights.detect_anomalies()]
    assert 'Large transfer (pending)' in kinds
    inv.complete_transfer(big.id, user=mgr())  # never blocked
    assert Transfer.query.get(big.id).status == 'Done'
    assert any(f['kind'] == 'Large transfer' for f in insights.detect_anomalies())


def test_no_anomalies_without_enough_history(test_app):
    assert insights.check_quantity('Internal Transfer', prod('SR001').id, 10000) is None


# -------------------------------------------------------------------------
# Scan / search / assistant
# -------------------------------------------------------------------------

def test_lookup_actions_respect_role(client, test_app):
    as_manager(client)
    d = client.get('/api/lookup?code=sr001').get_json()
    assert d['found'] and d['product']['sku'] == 'SR001'
    keys = {a['key']: a for a in d['actions']}
    assert keys['receive']['url'].startswith('/receipts/new')

    as_staff(client)
    d = client.get('/api/lookup?code=SR001').get_json()
    keys = {a['key']: a for a in d['actions']}
    assert not (keys['receive']['url'] or '').startswith('/receipts/new')
    assert 'adjust' in keys and keys['adjust']['label'] == 'Count'

    d = client.get('/api/lookup?code=REC-0004').get_json()
    assert d['type'] == 'document' and d['url'].startswith('/receipts/')
    d = client.get('/api/lookup?code=nothing-here').get_json()
    assert d['found'] is False


def test_global_search_covers_new_entities(client, test_app):
    as_manager(client)
    cats = {r['category'] for r in client.get('/search?q=WH2').get_json()['results']}
    assert 'Warehouse' in cats and 'Location' in cats
    cats = {r['category'] for r in client.get('/search?q=INT-0001').get_json()['results']}
    assert 'Internal Transfer' in cats and 'Ledger' in cats


def test_assistant_answers_from_data(client, test_app):
    as_staff(client)
    res = client.post('/api/assistant', json={'question': 'Which products are out of stock?'}).get_json()
    assert res['intent'] == 'out_of_stock' and res['rows'][0][1] == 'LP005'
    res = client.post('/api/assistant', json={'question': 'How much Steel Rod is currently available?'}).get_json()
    assert f"{get_on_hand(prod('SR001').id):g} kg" in res['answer']
    res = client.post('/api/assistant', json={'question': 'tell me a joke'}).get_json()
    assert res['intent'] is None


def test_assistant_provider_hook_falls_back(test_app):
    class Broken:
        def answer(self, *a, **k):
            raise RuntimeError('offline')
    assistant.register_provider(Broken())
    try:
        assert assistant.ask('Which products are out of stock?', mgr())['intent'] == 'out_of_stock'
    finally:
        assistant.register_provider(None)


# -------------------------------------------------------------------------
# Schema upgrade for pre-existing databases
# -------------------------------------------------------------------------

def test_additive_schema_upgrade(tmp_path):
    path = tmp_path / 'legacy.db'
    eng = create_engine(f'sqlite:///{path}')
    with eng.begin() as c:
        c.execute(text('CREATE TABLE warehouses (id INTEGER PRIMARY KEY, name VARCHAR(100), code VARCHAR(20), address VARCHAR(255), active BOOLEAN)'))
        c.execute(text('CREATE TABLE locations (id INTEGER PRIMARY KEY, warehouse_id INTEGER, name VARCHAR(100), code VARCHAR(50), active BOOLEAN)'))
        c.execute(text("INSERT INTO warehouses VALUES (1, 'Old', 'OLD', NULL, 1)"))

    class LegacyConfig:
        SECRET_KEY = 'x'
        SQLALCHEMY_DATABASE_URI = f'sqlite:///{path}'
        SQLALCHEMY_TRACK_MODIFICATIONS = False
        WTF_CSRF_ENABLED = False
        TESTING = True

    app = create_app(LegacyConfig)
    with app.app_context():
        wh = Warehouse.query.get(1)
        assert wh.name == 'Old' and wh.capacity is None
    cols = {r[1] for r in create_engine(f'sqlite:///{path}').connect().execute(text('PRAGMA table_info(locations)'))}
    assert {'capacity', 'location_type'} <= cols
