// StockSense public pages: gentle pointer + scroll parallax for the floating cards.
// Writes three CSS custom properties on .fc-field; all motion is done in CSS.
(function () {
  var field = document.querySelector('[data-parallax]');
  if (!field) return;

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (reduce.matches) return;

  var target = { x: 0, y: 0 }, cur = { x: 0, y: 0 }, sy = 0, raf = null;
  var finePointer = window.matchMedia('(pointer: fine)').matches;

  function tick() {
    // critically damped-ish easing: slow, smooth follow
    cur.x += (target.x - cur.x) * 0.045;
    cur.y += (target.y - cur.y) * 0.045;
    field.style.setProperty('--mx', cur.x.toFixed(4));
    field.style.setProperty('--my', cur.y.toFixed(4));
    field.style.setProperty('--sy', sy.toFixed(1));
    if (Math.abs(target.x - cur.x) > 0.0005 || Math.abs(target.y - cur.y) > 0.0005) {
      raf = requestAnimationFrame(tick);
    } else {
      raf = null;
    }
  }
  function kick() { if (!raf) raf = requestAnimationFrame(tick); }

  if (finePointer) {
    window.addEventListener('pointermove', function (e) {
      target.x = (e.clientX / window.innerWidth) * 2 - 1;
      target.y = (e.clientY / window.innerHeight) * 2 - 1;
      kick();
    }, { passive: true });
    document.addEventListener('pointerleave', function () { target.x = 0; target.y = 0; kick(); });
  }

  window.addEventListener('scroll', function () {
    sy = Math.min(window.scrollY, window.innerHeight);
    kick();
  }, { passive: true });

  reduce.addEventListener && reduce.addEventListener('change', function (e) {
    if (e.matches) { field.style.setProperty('--mx', 0); field.style.setProperty('--my', 0); field.style.setProperty('--sy', 0); }
  });
})();
