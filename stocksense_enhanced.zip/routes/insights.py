"""
Warehouse intelligence routes: warehouse map & floor map, alert center,
analytics, forecasting, audit trail, anomaly review, scanning and the
"Ask StockSense" assistant. All read from the stock ledger via services.insights.
"""
from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash, abort, current_app
from flask_login import login_required, current_user

from models import db, Product, Warehouse, Location, Receipt, ReceiptItem, Delivery, DeliveryItem, \
    Transfer, Adjustment, AdjustmentItem, User
from services import insights, assistant
from services.permissions import require_permission, can
from services.stock_engine import get_status

insights_bp = Blueprint('insights', __name__)


def _float_or_none(val):
    val = (val or '').strip() if isinstance(val, str) else val
    if val in (None, ''):
        return None
    try:
        return float(val)
    except (TypeError, ValueError):
        raise ValueError


# =========================================================================
# WAREHOUSE MAP & FLOOR MAP
# =========================================================================

@insights_bp.route('/warehouses')
@login_required
@require_permission('map:view')
def warehouse_map():
    data = insights.warehouse_overview()
    markers = [{
        'id': w['id'], 'name': w['name'], 'code': w['code'], 'address': w['address'] or '',
        'lat': w['latitude'], 'lng': w['longitude'], 'stock': w['stock'],
        'products': w['product_count'], 'low': w['low_stock_count'],
        'receipts': len(w['pending_receipts']), 'deliveries': len(w['pending_deliveries']),
        'util': w['util']['pct'], 'level': w['util']['level'],
        'url': url_for('insights.warehouse_detail', id=w['id']),
    } for w in data]
    has_coords = any(m['lat'] is not None and m['lng'] is not None for m in markers)
    return render_template('warehouses/map.html', warehouses=data, markers=markers, has_coords=has_coords,
                           tile_url=current_app.config.get('MAP_TILE_URL'),
                           tile_attribution=current_app.config.get('MAP_TILE_ATTRIBUTION'))


@insights_bp.route('/warehouses/<int:id>')
@login_required
@require_permission('map:view')
def warehouse_detail(id):
    wh = Warehouse.query.get_or_404(id)
    w = insights.warehouse_overview(wh)[0]
    zones = {'Storage': [], 'Rack': [], 'Production': [], 'Loading': []}
    for loc in w['locations']:
        zones.setdefault(loc['zone_type'], []).append(loc)
    selected = request.args.get('location', type=int)
    loc_json = {str(l['id']): {
        'id': l['id'], 'name': l['name'], 'code': l['code'], 'zone': l['zone_type'], 'active': l['active'],
        'used': l['used'], 'capacity': l['capacity'], 'util': l['util'],
        'products': [{'id': p['product_id'], 'name': p['name'], 'sku': p['sku'], 'uom': p['uom'],
                      'qty': p['quantity'], 'reorder': p['reorder_level'], 'status': p['status']}
                     for p in l['products']],
    } for l in w['locations']}
    return render_template('warehouses/detail.html', w=w, zones=zones, loc_json=loc_json, selected=selected,
                           location_types=['Storage', 'Rack', 'Production', 'Loading'])


@insights_bp.route('/warehouses/<int:id>/configure', methods=['POST'])
@login_required
@require_permission('settings:manage')
def warehouse_configure(id):
    wh = Warehouse.query.get_or_404(id)
    try:
        cap = _float_or_none(request.form.get('capacity'))
        lat = _float_or_none(request.form.get('latitude'))
        lng = _float_or_none(request.form.get('longitude'))
    except ValueError:
        flash("Capacity and coordinates must be numbers.", "error")
        return redirect(url_for('insights.warehouse_detail', id=id))
    if cap is not None and cap <= 0:
        flash("Capacity must be greater than zero.", "error")
        return redirect(url_for('insights.warehouse_detail', id=id))
    if (lat is None) != (lng is None) or (lat is not None and not (-90 <= lat <= 90 and -180 <= lng <= 180)):
        flash("Provide both latitude (-90..90) and longitude (-180..180), or leave both empty.", "error")
        return redirect(url_for('insights.warehouse_detail', id=id))
    wh.capacity, wh.latitude, wh.longitude = cap, lat, lng

    for loc in wh.locations:
        raw_cap = request.form.get(f'loc_capacity_{loc.id}')
        raw_type = request.form.get(f'loc_type_{loc.id}')
        if raw_cap is not None:
            try:
                lc = _float_or_none(raw_cap)
            except ValueError:
                db.session.rollback()
                flash(f"Capacity for {loc.code} must be a number.", "error")
                return redirect(url_for('insights.warehouse_detail', id=id))
            if lc is not None and lc <= 0:
                db.session.rollback()
                flash(f"Capacity for {loc.code} must be greater than zero.", "error")
                return redirect(url_for('insights.warehouse_detail', id=id))
            loc.capacity = lc
        if raw_type is not None:
            loc.location_type = raw_type if raw_type in ('Storage', 'Rack', 'Production', 'Loading') else None

    from services.inventory_service import log_activity
    log_activity('Warehouse', wh.id, current_user.id, 'Warehouse layout updated',
                 f"{wh.code}: capacity={cap if cap is not None else 'not set'}")
    db.session.commit()
    flash(f"Capacity and layout settings saved for {wh.name}.", "success")
    return redirect(url_for('insights.warehouse_detail', id=id))


# =========================================================================
# ALERT CENTER
# =========================================================================

@insights_bp.route('/alerts')
@login_required
@require_permission('alerts:view')
def alert_center():
    alerts = insights.build_alerts(current_user)
    severity = request.args.get('severity', '')
    category = request.args.get('category', '')
    counts = {s: sum(1 for a in alerts if a['severity'] == s) for s in ('critical', 'warning', 'info')}
    categories = sorted({a['category'] for a in alerts})
    shown = [a for a in alerts if (not severity or a['severity'] == severity) and (not category or a['category'] == category)]
    return render_template('insights/alerts.html', alerts=shown, counts=counts, total=len(alerts),
                           categories=categories, severity=severity, category=category)


@insights_bp.route('/api/alerts/summary')
@login_required
@require_permission('alerts:view')
def alert_summary():
    alerts = insights.build_alerts(current_user)
    return jsonify({
        'count': len(alerts),
        'critical': sum(1 for a in alerts if a['severity'] == 'critical'),
        'warning': sum(1 for a in alerts if a['severity'] == 'warning'),
    })


# =========================================================================
# ANALYTICS / FORECASTING / AUDIT / ANOMALIES (manager only)
# =========================================================================

@insights_bp.route('/analytics')
@login_required
@require_permission('analytics:view')
def analytics():
    days = request.args.get('days', 30, type=int)
    if days not in (7, 30, 90):
        days = 30
    return render_template('insights/analytics.html', a=insights.analytics(days))


@insights_bp.route('/forecasting')
@login_required
@require_permission('forecast:view')
def forecasting():
    rows = insights.forecast_all()
    return render_template('insights/forecasting.html', rows=rows,
                           sufficient_count=sum(1 for r in rows if r['sufficient']),
                           cfg={'window': insights.FORECAST_WINDOW_DAYS, 'min_span': insights.FORECAST_MIN_SPAN_DAYS,
                                'min_events': insights.FORECAST_MIN_EVENTS, 'cover': insights.FORECAST_COVER_DAYS})


@insights_bp.route('/audit-trail')
@login_required
@require_permission('audit:view')
def audit_trail():
    entries = insights.audit_entries()
    kind = request.args.get('kind', '')
    user_id = request.args.get('user', type=int)
    product_id = request.args.get('product', type=int)
    q = request.args.get('q', '').strip().lower()
    date_from = request.args.get('from', '')
    date_to = request.args.get('to', '')

    def keep(e):
        if kind and e['kind'] != kind:
            return False
        if user_id and (not e['user'] or e['user'].id != user_id):
            return False
        if product_id and (not e['product'] or e['product'].id != product_id):
            return False
        if q:
            hay = ' '.join(filter(None, [e['action'], e['reference'], e['reason'], e['operation'],
                                         e['product'].name if e['product'] else None,
                                         e['product'].sku if e['product'] else None])).lower()
            if q not in hay:
                return False
        try:
            if date_from and e['at'] < datetime.strptime(date_from, '%Y-%m-%d'):
                return False
            if date_to and e['at'] >= datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1):
                return False
        except ValueError:
            pass
        return True

    filtered = [e for e in entries if keep(e)]
    page = max(1, request.args.get('page', 1, type=int))
    per_page = 30
    total_pages = max(1, (len(filtered) + per_page - 1) // per_page)
    page = min(page, total_pages)
    return render_template('insights/audit.html', entries=filtered[(page - 1) * per_page: page * per_page],
                           total=len(filtered), page=page, total_pages=total_pages,
                           users=User.query.order_by(User.name).all(),
                           products=Product.query.order_by(Product.name).all(),
                           f={'kind': kind, 'user': user_id, 'product': product_id, 'q': request.args.get('q', ''),
                              'from': date_from, 'to': date_to})


@insights_bp.route('/anomalies')
@login_required
@require_permission('anomalies:view')
def anomalies():
    return render_template('insights/anomalies.html', findings=insights.detect_anomalies(),
                           cfg={'min_samples': insights.ANOMALY_MIN_SAMPLES, 'repeat': insights.ANOMALY_REPEAT_ADJ_COUNT,
                                'repeat_days': insights.ANOMALY_REPEAT_ADJ_DAYS, 'sudden': insights.ANOMALY_SUDDEN_CHANGE_PCT})


@insights_bp.route('/api/anomaly-check')
@login_required
def anomaly_check():
    if not (can('transfers:create') or can('adjustments:count')):
        abort(403)
    op = request.args.get('operation', 'Internal Transfer')
    if op not in ('Internal Transfer', 'Adjustment', 'Delivery'):
        return jsonify({'error': 'Unsupported operation'}), 400
    pid = request.args.get('product', type=int)
    qty = request.args.get('qty', type=float)
    if not pid or qty is None or qty <= 0:
        return jsonify({'unusual': False})
    adv = insights.check_quantity(op, pid, qty)
    if not adv:
        return jsonify({'unusual': False})
    p = Product.query.get(pid)
    return jsonify({'unusual': True, 'message':
                    f"Unusual quantity: {qty:g} {p.uom}. Typical {adv['scope']}: "
                    f"{adv['typical_low']:g}–{adv['typical_high']:g} {p.uom}. You can still proceed; this is flagged for review."})


# =========================================================================
# SCANNING
# =========================================================================

def _scan_actions(p, bal):
    actions = [{'key': 'view', 'label': 'View Stock', 'icon': 'inventory_2', 'url': url_for('products.detail', id=p.id)}]

    if can('receipts:create'):
        actions.append({'key': 'receive', 'label': 'Receive', 'icon': 'move_to_inbox', 'url': f'/receipts/new?product_id={p.id}'})
    elif can('receipts:receive'):
        open_recs = Receipt.query.join(ReceiptItem).filter(ReceiptItem.product_id == p.id,
                                                           Receipt.status.in_(('Waiting', 'Ready'))).all()
        actions.append({'key': 'receive', 'label': 'Receive', 'icon': 'move_to_inbox',
                        'url': f'/receipts/{open_recs[0].id}' if len(open_recs) == 1 else ('/receipts?tab=waiting' if open_recs else None),
                        'hint': f"{len(open_recs)} open receipt(s)" if open_recs else 'No receipts awaiting this product'})

    if can('deliveries:create'):
        actions.append({'key': 'deliver', 'label': 'Deliver', 'icon': 'local_shipping', 'url': f'/delivery-orders/new?product_id={p.id}'})
    elif can('deliveries:pick'):
        open_dels = Delivery.query.join(DeliveryItem).filter(DeliveryItem.product_id == p.id,
                                                              Delivery.status.in_(('Ready', 'Picked'))).all()
        actions.append({'key': 'deliver', 'label': 'Deliver', 'icon': 'local_shipping',
                        'url': f'/delivery-orders/{open_dels[0].id}' if len(open_dels) == 1 else ('/delivery-orders?tab=ready' if open_dels else None),
                        'hint': f"{len(open_dels)} order(s) to pick/pack" if open_dels else 'No orders to pick for this product'})

    if can('transfers:create'):
        src = max(((lid, q) for (pid, lid), q in bal.items() if pid == p.id and q > 0), key=lambda x: x[1], default=None)
        url = f'/internal-transfers/new?product_id={p.id}' + (f'&source_id={src[0]}' if src else '')
        actions.append({'key': 'transfer', 'label': 'Transfer', 'icon': 'swap_horiz', 'url': url})

    if can('adjustments:create'):
        actions.append({'key': 'adjust', 'label': 'Adjust', 'icon': 'tune', 'url': f'/inventory-adjustments/new?product_id={p.id}'})
    elif can('adjustments:count'):
        sheets = Adjustment.query.join(AdjustmentItem).filter(AdjustmentItem.product_id == p.id,
                                                               Adjustment.status == 'Draft').all()
        actions.append({'key': 'adjust', 'label': 'Count', 'icon': 'fact_check',
                        'url': f'/inventory-adjustments/{sheets[0].id}' if len(sheets) == 1 else ('/inventory-adjustments?tab=draft' if sheets else None),
                        'hint': f"{len(sheets)} count sheet(s)" if sheets else 'No open count sheet for this product'})
    return actions


@insights_bp.route('/scan')
@login_required
@require_permission('scan:use')
def scan():
    return render_template('insights/scan.html', initial_code=request.args.get('code', ''))


@insights_bp.route('/api/lookup')
@login_required
@require_permission('scan:use')
def lookup():
    code = (request.args.get('code') or '').strip()
    if not code:
        return jsonify({'found': False, 'message': 'Enter or scan a code.'}), 400
    up = code.upper()

    # Document references (REC-/DO-/INT-/ADJ-) resolve to their record
    for model, bp in ((Receipt, 'receipts'), (Delivery, 'deliveries'), (Transfer, 'transfers'), (Adjustment, 'adjustments')):
        doc = model.query.filter(db.func.upper(model.reference) == up).first()
        if doc:
            return jsonify({'found': True, 'type': 'document', 'reference': doc.reference,
                            'url': url_for(f'{bp}.detail', id=doc.id)})

    p = Product.query.filter(db.func.upper(Product.sku) == up).first()
    if not p:
        matches = Product.query.filter(db.or_(Product.sku.ilike(f'%{code}%'), Product.name.ilike(f'%{code}%'))).limit(6).all()
        if len(matches) == 1:
            p = matches[0]
        else:
            return jsonify({'found': False, 'message': f'No product found for code "{code}".',
                            'candidates': [{'id': m.id, 'name': m.name, 'sku': m.sku} for m in matches]})

    bal = insights.location_balances()
    locs = []
    total = 0.0
    for (pid, lid), q in sorted(bal.items(), key=lambda kv: -kv[1]):
        if pid == p.id and abs(q) > 1e-9:
            loc = Location.query.get(lid)
            locs.append({'code': loc.code, 'name': loc.name, 'warehouse': loc.warehouse.name, 'qty': q})
            total += q
    return jsonify({
        'found': True, 'type': 'product',
        'product': {'id': p.id, 'name': p.name, 'sku': p.sku, 'uom': p.uom, 'archived': p.archived,
                    'category': p.category.name if p.category else None, 'reorder_level': p.reorder_level,
                    'on_hand': total, 'status': get_status(p, total)},
        'locations': locs,
        'actions': _scan_actions(p, bal),
    })


# =========================================================================
# ASK STOCKSENSE
# =========================================================================

@insights_bp.route('/assistant')
@login_required
@require_permission('assistant:use')
def assistant_page():
    return render_template('insights/assistant.html', suggestions=assistant.SUGGESTIONS,
                           provider=assistant.provider_name())


@insights_bp.route('/api/assistant', methods=['POST'])
@login_required
@require_permission('assistant:use')
def assistant_api():
    payload = request.get_json(silent=True) or {}
    question = payload.get('question') or request.form.get('question', '')
    return jsonify(assistant.ask(question[:500], current_user))
