from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, url_for
from flask_login import login_required, current_user
from models import db, Product, Location, Warehouse, Receipt, Delivery, Transfer, Adjustment, Supplier, Customer, StockMovement
from services.stock_engine import get_on_hand, get_available, get_reserved, get_status

api_bp = Blueprint('api', __name__)

@api_bp.route('/api/stock')
@login_required
def get_stock_info():
    product_id = request.args.get('product', type=int)
    location_id = request.args.get('location', type=int)

    if not product_id:
        return jsonify({'error': 'Product ID is required'}), 400

    product = Product.query.get(product_id)
    if not product:
        return jsonify({'error': 'Product not found'}), 404

    on_hand = get_on_hand(product_id, location_id)
    reserved = get_reserved(product_id, location_id)
    available = max(0.0, on_hand - reserved)
    status = get_status(product, on_hand)

    return jsonify({
        'product_id': product.id,
        'product_name': product.name,
        'sku': product.sku,
        'uom': product.uom,
        'location_id': location_id,
        'on_hand': on_hand,
        'reserved': reserved,
        'available': available,
        'status': status
    })


@api_bp.route('/search')
@login_required
def global_search():
    q = request.args.get('q', '').strip()
    if not q or len(q) < 2:
        return jsonify({'results': []})

    results = []

    # 1. Products
    products = Product.query.filter(
        db.or_(
            Product.name.ilike(f"%{q}%"),
            Product.sku.ilike(f"%{q}%")
        )
    ).limit(5).all()
    products.sort(key=lambda p: (p.sku.upper() != q.upper(), p.name))
    for p in products:
        results.append({
            'category': 'Product',
            'title': f"{p.name} ({p.sku})",
            'subtitle': f"Reorder: {p.reorder_level} {p.uom} · Total On-Hand: {get_on_hand(p.id)} {p.uom}",
            'url': url_for('products.detail', id=p.id)
        })

    # 2. Receipts (REC, PO)
    receipts = Receipt.query.filter(
        db.or_(
            Receipt.reference.ilike(f"%{q}%"),
            Receipt.source_document.ilike(f"%{q}%")
        )
    ).limit(4).all()
    for r in receipts:
        results.append({
            'category': 'Receipt',
            'title': r.reference,
            'subtitle': f"{r.supplier.name} · {r.status} · PO: {r.source_document or 'N/A'}",
            'url': url_for('receipts.detail', id=r.id)
        })

    # 3. Deliveries (DO, SO)
    deliveries = Delivery.query.filter(
        db.or_(
            Delivery.reference.ilike(f"%{q}%"),
            Delivery.source_document.ilike(f"%{q}%")
        )
    ).limit(4).all()
    for d in deliveries:
        results.append({
            'category': 'Delivery Order',
            'title': d.reference,
            'subtitle': f"{d.customer.name} · {d.status} ({d.priority})",
            'url': url_for('deliveries.detail', id=d.id)
        })

    # 4. Transfers (INT)
    transfers = Transfer.query.filter(db.or_(Transfer.reference.ilike(f"%{q}%"), Transfer.reason.ilike(f"%{q}%"))).limit(3).all()
    for t in transfers:
        results.append({
            'category': 'Internal Transfer',
            'title': t.reference,
            'subtitle': f"{t.source_location.code} → {t.destination_location.code} ({t.status})",
            'url': url_for('transfers.detail', id=t.id)
        })

    # 5. Adjustments (ADJ)
    adjustments = Adjustment.query.filter(
        db.or_(
            Adjustment.reference.ilike(f"%{q}%"),
            Adjustment.title.ilike(f"%{q}%")
        )
    ).limit(3).all()
    for a in adjustments:
        results.append({
            'category': 'Inventory Adjustment',
            'title': f"{a.reference} - {a.title}",
            'subtitle': f"Status: {a.status}",
            'url': url_for('adjustments.detail', id=a.id)
        })

    # 6. Warehouses & locations
    whs = Warehouse.query.filter(db.or_(Warehouse.name.ilike(f"%{q}%"), Warehouse.code.ilike(f"%{q}%"),
                                        Warehouse.address.ilike(f"%{q}%"))).limit(3).all()
    for w in whs:
        results.append({
            'category': 'Warehouse',
            'title': f"{w.name} ({w.code})",
            'subtitle': w.address or f"{len(w.locations)} locations",
            'url': url_for('insights.warehouse_detail', id=w.id)
        })
    locs = Location.query.filter(db.or_(Location.name.ilike(f"%{q}%"), Location.code.ilike(f"%{q}%"))).limit(4).all()
    for l in locs:
        results.append({
            'category': 'Location',
            'title': f"{l.name} ({l.code})",
            'subtitle': f"{l.warehouse.name} · {l.zone_type}{'' if l.active else ' · Inactive'}",
            'url': url_for('insights.warehouse_detail', id=l.warehouse_id, location=l.id)
        })

    # 7. Documents by counterparty (supplier / customer names)
    seen = {r['title'] for r in results}
    for r in Receipt.query.join(Supplier).filter(Supplier.name.ilike(f"%{q}%")).order_by(Receipt.created_at.desc()).limit(3).all():
        if r.reference not in seen:
            results.append({'category': 'Receipt', 'title': r.reference,
                            'subtitle': f"{r.supplier.name} · {r.status}", 'url': url_for('receipts.detail', id=r.id)})
    for d in Delivery.query.join(Customer).filter(Customer.name.ilike(f"%{q}%")).order_by(Delivery.created_at.desc()).limit(3).all():
        if d.reference not in seen:
            results.append({'category': 'Delivery Order', 'title': d.reference,
                            'subtitle': f"{d.customer.name} · {d.status}", 'url': url_for('deliveries.detail', id=d.id)})

    # 8. Stock ledger entries (staff are limited to the last 30 days, as on Move History)
    ledger_q = StockMovement.query.join(Product, StockMovement.product_id == Product.id).filter(db.or_(
        StockMovement.reference.ilike(f"%{q}%"), StockMovement.counterparty.ilike(f"%{q}%"),
        Product.name.ilike(f"%{q}%"), Product.sku.ilike(f"%{q}%")))
    if not current_user.is_manager:
        ledger_q = ledger_q.filter(StockMovement.at >= datetime.utcnow() - timedelta(days=30))
    for m in ledger_q.order_by(StockMovement.at.desc()).limit(4).all():
        results.append({
            'category': 'Ledger',
            'title': f"{m.reference} · {m.operation}",
            'subtitle': f"{m.product.name} {m.quantity:g} {m.product.uom} · "
                        f"{m.from_location.code if m.from_location else 'External'} → {m.to_location.code if m.to_location else 'External'} · {m.at.strftime('%Y-%m-%d')}",
            'url': url_for('history.index', q=m.reference)
        })

    return jsonify({'results': results})


@api_bp.route('/notifications')
@login_required
def notifications():
    """
    Topbar notification dropdown. Backed by the Alert Center engine so the bell,
    the badge and /alerts always agree. Response shape is unchanged.
    """
    from services.insights import build_alerts
    type_map = {'critical': 'error', 'warning': 'warning', 'info': 'info'}
    alerts = build_alerts(current_user)
    items = [{
        'title': a['title'],
        'desc': a['message'],
        'url': a['url'],
        'type': type_map[a['severity']],
        'severity': a['severity'],
    } for a in alerts]
    return jsonify({
        'count': len(items),
        'notifications': items[:10]
    })
